#!/usr/bin/env python

from distutils.core import setup

setup(name='qikify',
      version='0.0.1',
      description='Qikify: A MVC Adaptive Test Solution',
      author='Nathan Kupp',
      author_email='nathan.kupp@yale.edu',
      url='http://github.com/trela/qikify',
      packages=['qikify', 'qikify.models', 'qikify.helpers', 'qikify.examples', 
                'qikify.controllers.kde', 'qikify.controllers.lsfs', 'qikify.controllers.svm'],
     )